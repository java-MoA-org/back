package com.MoA.moa_back.common.enums;

public enum JwtErrorCode {
    EXPIRED,   // 토큰 만료
    INVALID    // 위조, 구조 오류 등
}

