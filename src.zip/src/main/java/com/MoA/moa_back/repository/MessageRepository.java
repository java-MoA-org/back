package com.MoA.moa_back.repository;

import com.MoA.moa_back.common.entity.MessageEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MessageRepository extends JpaRepository<MessageEntity, Long> {

    // 두 유저 간 대화 이력 조회
    @Query("SELECT m FROM MessageEntity m WHERE " +
           "(m.senderId = :userA AND m.receiverId = :userB) OR " +
           "(m.senderId = :userB AND m.receiverId = :userA) " +
           "ORDER BY m.timestamp ASC")
    List<MessageEntity> findChatHistory(@Param("userA") String userA, @Param("userB") String userB);

    // 특정 유저가 포함된 전체 메시지 조회
    List<MessageEntity> findBySenderIdOrReceiverId(String senderId, String receiverId);
}