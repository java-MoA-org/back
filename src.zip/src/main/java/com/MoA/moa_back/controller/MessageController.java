package com.MoA.moa_back.controller;

import com.MoA.moa_back.common.entity.MessageEntity;
import com.MoA.moa_back.service.MessageService;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
// import org.springframework.messaging.handler.annotation.SendToUser;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

@Controller
public class MessageController {

    private final MessageService messageService;
    private final SimpMessagingTemplate messagingTemplate;

    public MessageController(MessageService messageService, SimpMessagingTemplate messagingTemplate) {
        this.messageService = messageService;
        this.messagingTemplate = messagingTemplate;
    }

    @MessageMapping("/send")
    public void handleMessage(@Payload MessageEntity message) {
        // 1. DB 저장
        MessageEntity saved = messageService.saveMessage(
            message.getSenderId(), message.getReceiverId(), message.getContent()
        );
    
        // 2. 수신자에게 전송 (Spring이 자동으로 /user/ 붙여줌)
        messagingTemplate.convertAndSendToUser(
            saved.getReceiverId(), "/queue/messages", saved
        );
    }
}