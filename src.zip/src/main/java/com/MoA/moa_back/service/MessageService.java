package com.MoA.moa_back.service;

import com.MoA.moa_back.common.entity.MessageEntity;

import java.util.List;

public interface MessageService {

    // 메시지 저장
    MessageEntity saveMessage(String senderId, String receiverId, String content);

    // 두 유저 간 채팅 이력 조회
    List<MessageEntity> getChatHistory(String userA, String userB);

    // 특정 유저가 포함된 모든 메시지 조회
    List<MessageEntity> getAllMessagesForUser(String userId);
}