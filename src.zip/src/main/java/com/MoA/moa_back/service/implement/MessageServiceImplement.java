package com.MoA.moa_back.service.implement;

import com.MoA.moa_back.common.entity.MessageEntity;
import com.MoA.moa_back.repository.MessageRepository;
import com.MoA.moa_back.service.MessageService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MessageServiceImplement implements MessageService {

    private final MessageRepository messageRepository;

    @Override
    public MessageEntity saveMessage(String senderId, String receiverId, String content) {
        MessageEntity message = MessageEntity.builder()
                .senderId(senderId)
                .receiverId(receiverId)
                .content(content)
                .build();

        return messageRepository.save(message);
    }

    @Override
    public List<MessageEntity> getChatHistory(String userA, String userB) {
        return messageRepository.findChatHistory(userA, userB);
    }

    @Override
    public List<MessageEntity> getAllMessagesForUser(String userId) {
        return messageRepository.findBySenderIdOrReceiverId(userId, userId);
    }
}