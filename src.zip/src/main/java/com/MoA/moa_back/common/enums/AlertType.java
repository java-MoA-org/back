package com.MoA.moa_back.common.enums;

public enum AlertType {
  SYSTEM,
  COMMENT,
  LIKE;
  
}
