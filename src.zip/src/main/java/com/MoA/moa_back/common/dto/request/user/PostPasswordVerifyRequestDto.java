package com.MoA.moa_back.common.dto.request.user;

import lombok.Getter;

@Getter
public class PostPasswordVerifyRequestDto {
  private String userPassword;
}
