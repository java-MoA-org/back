package com.MoA.moa_back.common.dto.request.message;

import lombok.Getter;

@Getter
public class HideMessageRequestDto {
  private Integer messageNumber;
}
