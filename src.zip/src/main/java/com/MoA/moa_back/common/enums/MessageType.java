
package com.MoA.moa_back.common.enums;

public enum MessageType {
    TEXT,
    IMAGE,
    DELETE,
    READ
}