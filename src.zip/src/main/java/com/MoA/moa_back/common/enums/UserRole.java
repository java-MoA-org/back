package com.MoA.moa_back.common.enums;

public enum UserRole {
    USER,
    ADMIN
}